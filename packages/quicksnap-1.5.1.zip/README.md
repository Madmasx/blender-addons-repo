# QuickSnap
QuickSnap is a Blender extension to quickly snap objects/vertices/points to object origins/vertices/points, similar to how vertex snap works in Maya/3Dsmax.

Presentation video:

https://user-images.githubusercontent.com/35562774/195340412-6931d8f0-045d-4c4d-badd-96b94ef7f1cc.mp4

If the video is not playing for you, you can watch it here: https://youtu.be/9cWV0JELM88


## Features

* Snap From/To:
  * Object origins
  * Vertices and Curve points
  * Edge mid-points
  * Face centers

* Change the snap type using hotkeys: **1** — Vertices/curve points, **2** — Edge midpoints, **3** — Face centers, **O** — Origins

* An icon near the mouse shows the current snap target type (always visible, fade after a few seconds, or disabled — configurable in preferences)

    ![hotkey-icon](https://user-images.githubusercontent.com/35562774/199265091-24b63cdf-780b-4aa1-847c-cfb486469356.gif)

* Works in orthographic view (Numpad 5) and local view (Numpad /)

* Two workflow options:
  * **Click and drag** — pick source and drag to target in one motion
  * **Two clicks** — click source, reposition camera if needed, then click target

    ![two-click-workflow](https://user-images.githubusercontent.com/35562774/199266031-7d27c422-83dd-4f15-a051-341dd86d6d93.gif)

* Works with no selection:
  * In Object mode the object under the mouse is moved to the target position

    ![no_selection_object_mode](https://user-images.githubusercontent.com/35562774/199267351-c29a4a40-bf31-4968-87ef-8a1debe4ebc4.gif)

  * In Edit mode the points under the mouse are moved, and merged if auto-merge is enabled

    ![no_selection_edit_mode](https://user-images.githubusercontent.com/35562774/199267808-46811c4c-3b9f-456b-84eb-d603e7aba780.gif)

* Pie menu to change the snap type — open with the same hotkey used to launch the tool

    ![pie-menu](https://user-images.githubusercontent.com/35562774/196196537-82078f77-70ab-4929-a36a-6aaf6fe3bfde.gif)

* Auto-merge vertices in Edit mode when snapping to an overlapping vertex

    ![auto-merge](https://user-images.githubusercontent.com/35562774/196421064-38042819-71df-452c-955c-cbf34977f6d9.gif)
    ![image](https://user-images.githubusercontent.com/35562774/196762927-2d5b9616-748a-4b21-8ae9-984503721586.png)

* Constrain translation to a single axis or plane using **(Shift+)X / Y / Z**

* Automatically displays wireframe of the target mesh and the object under the mouse (can be disabled)

* Snaps to both visible and occluded points (points closer to the camera are prioritized)

* Highlights target vertex edges and nearby edge midpoints/face centers for better readability

    ![target_highlight](https://user-images.githubusercontent.com/35562774/196428455-6ba30a31-faeb-4c7c-9dbc-9b3dcca08af3.gif)


## Installation

QuickSnap is available on the Blender Extension platform:

1. In Blender, open **Edit > Preferences > Get Extensions**
2. Search for **QuickSnap**
3. Click **Install**

Alternatively, install manually from a downloaded `.zip`:

1. In Blender, open **Edit > Preferences > Add-ons**
2. Click **Install from Disk...** and select the downloaded `.zip`


## Hotkeys and Settings

* Enable the tool with **Ctrl+Shift+V** (for Vertex) by default
* Use the same hotkey to open the pie menu
* Change the tool hotkey and configure all preferences from **Edit > Preferences > Add-ons > QuickSnap**

    ![image](https://user-images.githubusercontent.com/35562774/199269100-9ae643af-ba5f-4ccd-a1f8-354b186f1c7f.png)

| Hotkey | Action |
|---|---|
| Ctrl+Shift+V | Enable tool / open pie menu |
| 1 | Snap from/to vertices and curve points |
| 2 | Snap from/to edge midpoints |
| 3 | Snap from/to face centers |
| O | Snap from/to object origins |
| X / Y / Z | Constrain to world axis |
| Shift+X / Y / Z | Constrain to world plane |
| W | Toggle wireframe on target |
| M | Toggle Ignore Modifiers |
| RMB / ESC | Cancel |


## How to Use

1. Select the objects or vertices/edges/faces/curve points you want to move
2. Enable the tool with **Ctrl+Shift+V**
3. Optionally select the snap type via hotkey or pie menu
4. Snap using one of two workflows:
   * **Click and drag** — hover over the source point, click and hold, move to the target, release
   * **Two clicks** — click the source point, then click the target point


## Performance Notes

QuickSnap is not designed for very high-poly scenes. Performance may degrade when many heavy objects are under the mouse. Hiding objects or collections you don't need to snap onto will help in those cases.

If a scene is particularly heavy, enabling **Ignore Modifiers** (M key) in the tool can also improve performance.


## Bug Reports

If you encounter an issue, please open a report on the [issue tracker](https://github.com/JulienHeijmans/quicksnap/issues). Include a description of what you were doing and what was in your scene. Attaching the scene file is always helpful.


## Known Issues / Limitations

* Target highlighting does not work with **Ignore Modifiers** enabled
* In Edit mode, the tool always uses the original mesh points (without modifiers applied)


## Version Support

* Blender 5.0 and newer
