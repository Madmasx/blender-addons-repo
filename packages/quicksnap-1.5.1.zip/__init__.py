import bpy
import importlib

if not bpy.app.background:
    from . import quicksnap_utils
    from . import quicksnap_snapdata
    from . import quicksnap_render
    from . import quicksnap


def register():
    if bpy.app.background:
        return
    importlib.reload(quicksnap_utils)
    importlib.reload(quicksnap_snapdata)
    importlib.reload(quicksnap_render)
    importlib.reload(quicksnap)
    quicksnap.register()


def unregister():
    if bpy.app.background:
        return
    quicksnap.unregister()
