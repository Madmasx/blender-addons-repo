import bpy

def register_props():
    bpy.types.Scene.ntp_options = bpy.props.PointerProperty(
        type=NTP_PG_Options
    )

def unregister_props():
    del bpy.types.Scene.ntp_options

class NTP_PG_Options(bpy.types.PropertyGroup):
    """
    Property group used during conversion of node group to python
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    # General properties
    mode: bpy.props.EnumProperty(
        name = "Mode",
        items = [
            ('SCRIPT', "Script", "Copy just the node group to the Blender clipboard"),
            ('ADDON', "Addon", "Create a full add-on")
        ]
    )
    set_group_defaults : bpy.props.BoolProperty(
        name = "Set Group Defaults",
        description = "Generate group socket default, min, and max values",
        default = True
    )
    set_node_sizes : bpy.props.BoolProperty(
        name = "Set Node Sizes",
        description = "Set dimensions of generated nodes",
        default = True
    )

    indentation_type: bpy.props.EnumProperty(
        name="Indentation Type",
        description="Whitespace to use for each indentation block",
        items = [
            ('SPACES_2', "2 Spaces", ""),
            ('SPACES_4', "4 Spaces", ""),
            ('SPACES_8', "8 Spaces", ""),
            ('TABS', "Tabs", "")
        ],
        default = 'SPACES_4'
    )

    link_external_node_groups : bpy.props.BoolProperty(
        name = "Link External Node Groups",
        description="Simply tries to link external node groups, otherwise copies",
        default = True
    )

    set_unavailable_defaults : bpy.props.BoolProperty(
        name = "Set unavailable defaults",
        description = "Set default values for unavailable sockets",
        default = False
    )

    #Script properties
    include_imports : bpy.props.BoolProperty(
        name = "Include Imports",
        description="Generate necessary import statements (i.e. bpy, mathutils, etc)",
        default = True
    )
    
    # Addon properties
    dir_path : bpy.props.StringProperty(
        name = "Save Location",
        subtype='DIR_PATH',
        description="Save location if generating an add-on",
        default = "//"
    )
    name : bpy.props.StringProperty(
        name = "Name",
        description="Name used for the add-on's",
        default = "My Add-on"
    )
    description : bpy.props.StringProperty(
        name = "Description",
        description="Description used for the add-on",
        default=""
    )
    author_name : bpy.props.StringProperty(
        name = "Author Name",
        description = "Name used for the author/maintainer of the add-on",
        default = "Node To Python"
    )
    version: bpy.props.IntVectorProperty(
        name = "Version",
        description="Version of the add-on",
        default = (1, 0, 0)
    )
    location: bpy.props.StringProperty(
        name = "Location",
        description="Location property of the addon",
        default="Node"
    )
    menu_id: bpy.props.StringProperty(
        name = "Menu ID",
        description = "Python ID of the menu you'd like to register the add-on "
                      "to. You can find these by enabling Python tooltips "
                      "(Preferences > Interface > Python tooltips) and "
                      "hovering over the desired menu",
        default="NODE_MT_add"
    )
    license: bpy.props.EnumProperty(
        name="License",
        items = [
            ('SPDX:GPL-3.0-or-later', "GNU General Public License v3.0 or later", ""),
            ('OTHER', "Other", "User is responsible for including the license "
                               "and adding it to the manifest.\n"
                               "Please note that by using the Blender Python "
                               "API, your add-on must comply with the GNU GPL. "
                               "See https://www.blender.org/about/license/ for "
                               "more details")
        ],
        default = 'SPDX:GPL-3.0-or-later'
    )
    should_create_license: bpy.props.BoolProperty(
        name="Create License",
        description="Should NodeToPython include a license file for your add-on",
        default=True
    )
    category: bpy.props.EnumProperty(
        name = "Category",
        items = [
            ('Custom',         "Custom",         "Use an unofficial category"),
            ('3D View',        "3D View",        ""),
            ('Add Curve',      "Add Curve",      ""),
            ('Add Mesh',       "Add Mesh",       ""),
            ('Animation',      "Animation",      ""),
            ('Bake',           "Bake",           ""),
            ('Compositing',    "Compositing",    ""),
            ('Development',    "Development",    ""),
            ('Game Engine',    "Game Engine",    ""),
            ('Geometry Nodes', "Geometry Nodes", ""),
            ("Grease Pencil",  "Grease Pencil",  ""),
            ('Import-Export',  "Import-Export",  ""),
            ('Lighting',       "Lighting",       ""),
            ('Material',       "Material",       ""),
            ('Mesh',           "Mesh",           ""),
            ('Modeling',       "Modeling",       ""),
            ('Node',           "Node",           ""),
            ('Object',         "Object",         ""),
            ('Paint',          "Paint",          ""),
            ('Pipeline',       "Pipeline",       ""),
            ('Physics',        "Physics",        ""),
            ('Render',         "Render",         ""),
            ('Rigging',        "Rigging",        ""),
            ('Scene',          "Scene",          ""),
            ('Sculpt',         "Sculpt",         ""),
            ('Sequencer',      "Sequencer",      ""),
            ('System',         "System",         ""),
            ('Text Editor',    "Text Editor",    ""),
            ('Tracking',       "Tracking",       ""),
            ('UV',             "UV",             ""),
            ('User Interface', "User Interface", ""),
        ],
        default = 'Node'
    )
    custom_category: bpy.props.StringProperty(
        name="Custom Category",
        description="Set the custom category property for your add-on",
        default = ""
    )


classes = [
    NTP_PG_Options
]